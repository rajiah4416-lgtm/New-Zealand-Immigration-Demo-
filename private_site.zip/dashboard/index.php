<?php include("../config/auth.php"); ?>
<h1>Dashboard</h1>
<ul>
<li><a href="/upload-client/index.php">Upload Client</a></li>
<li><a href="/view-client/index.php">View Clients</a></li>
<li><a href="/login/logout.php">Logout</a></li>
</ul>
