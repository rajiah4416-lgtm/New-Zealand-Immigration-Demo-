<?php include("../config/auth.php"); ?>
<h2>Upload Client</h2>
<form method="post" enctype="multipart/form-data">
<input type="text" name="name" placeholder="Client Name" required><br><br>
<input type="file" name="file" required><br><br>
<button type="submit">Upload</button>
</form>
<?php
if ($_FILES) {
    move_uploaded_file($_FILES['file']['tmp_name'], "../files/" . $_FILES['file']['name']);
    echo "Uploaded";
}
?>
