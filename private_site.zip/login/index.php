<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<style>
body { font-family: Arial; background:#f4f6f8; }
.login { width:300px; margin:100px auto; padding:20px; background:#fff; }
</style>
</head>
<body>
<div class="login">
<h2>Admin Login</h2>
<form method="post" action="login.php">
<input type="text" name="user" placeholder="Username" required><br><br>
<input type="password" name="pass" placeholder="Password" required><br><br>
<button type="submit">Login</button>
</form>
</div>
</body>
</html>
