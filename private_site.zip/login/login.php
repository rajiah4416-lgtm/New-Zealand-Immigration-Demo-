<?php
session_start();
if ($_POST['user'] == 'admin' && $_POST['pass'] == 'admin123') {
    $_SESSION['admin'] = true;
    header("Location: /dashboard/index.php");
} else {
    echo "Invalid login";
}
?>
