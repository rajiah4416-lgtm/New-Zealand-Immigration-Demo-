<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "private_site";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed");
}
?>
