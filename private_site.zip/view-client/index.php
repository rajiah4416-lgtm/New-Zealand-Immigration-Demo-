<?php include("../config/auth.php"); ?>
<h2>Files</h2>
<?php
$files = scandir("../files");
foreach ($files as $f) {
    if ($f != "." && $f != "..") {
        echo "<a href='/files/$f'>$f</a><br>";
    }
}
?>
